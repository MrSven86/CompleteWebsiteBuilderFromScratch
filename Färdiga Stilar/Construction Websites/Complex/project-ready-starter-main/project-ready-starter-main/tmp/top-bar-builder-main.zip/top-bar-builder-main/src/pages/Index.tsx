import TopBar from "@/components/TopBar";
import HeaderBar from "@/components/HeaderBar";
import NavBar from "@/components/NavBar";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <HeaderBar />
      <NavBar />
    </div>
  );
};

export default Index;
